# Interface mobile

Interface redesenhada a partir das referências: fundo preto, cartões grafite com degradê discreto, detalhes em malva, títulos com fonte Cormorant Garamond e navegação flutuante.

## Executar

Na pasta `mobile`, execute `npm ci` e `npx expo start`. A configuração `EXPO_PUBLIC_API_URL` continua apontando para a API do projeto. Para um celular físico, use o endereço de rede da máquina que executa o back-end.

## Telas

- Hoje: indicadores do dia, situação do caixa e próximos atendimentos.
- Agenda: dia, semana e mês; seleção de data e profissional; detalhes do atendimento ao tocar na linha.
- Comanda: serviços e produtos, total, sinal, saldo pendente e recebimento. Edição, pagamentos parciais e estornos ficam nos painéis de detalhes.
- Relatórios: período, indicadores, gráfico, ranking e exportação PDF/CSV. O filtro de profissional aplica-se ao gráfico e ao ranking; os indicadores financeiros são os totais do salão fornecidos pela API.
- Clientes: busca e atalho para agendamento; gestão completa acessível pela tela de clientes ou pelo perfil.

Valores, nomes, horários e estados são carregados da API. Não são números fixos das imagens. As telas de cliente preservam o acesso aos próprios agendamentos.

## Dependências visuais

`expo-linear-gradient` e `react-native-svg` foram adicionados com versões compatíveis com o SDK 57. A fonte é incluída no projeto, com sua licença em `assets/fonts/OFL.txt`, sem download em tempo de execução.

## Validação

TypeScript, lint e compilação web do Expo. Conferência visual em 430×932 e 360×800, com dados locais simulados para validar navegação, filtros, busca, recebimento e conclusão. O back-end foi preservado sem alterações.
