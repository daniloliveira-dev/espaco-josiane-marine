import React from "react";
import { useFonts } from "expo-font";
import { Stack, Redirect, useSegments } from "expo-router";
import { ActivityIndicator, View } from "react-native";
import { AuthProvider, useAuth } from "../core";
import { StatusBar } from "expo-status-bar";
function Routes() {
  const { session, ready } = useAuth();
  const [fontsLoaded, fontError] = useFonts({
    SalonDisplay: require("../../assets/fonts/Display.ttf"),
  });
  const segments = useSegments();
  if (!ready || (!fontsLoaded && !fontError))
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#030303",
          justifyContent: "center",
        }}
      >
        <ActivityIndicator color="#AF6892" />
      </View>
    );
  if (
    !session &&
    segments[0] !== undefined &&
    segments[0] !== "index" &&
    segments[0] !== "recovery"
  )
    return <Redirect href="/" />;
  return (
    <>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: "#030303" },
        }}
      />
    </>
  );
}
export default function Layout() {
  return (
    <AuthProvider>
      <Routes />
    </AuthProvider>
  );
}
