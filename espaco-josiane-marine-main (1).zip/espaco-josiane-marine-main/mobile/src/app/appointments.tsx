import React, { useState, useCallback } from "react";
import {
  Text,
  View,
  Alert,
  Platform,
  Modal,
  Pressable,
  ScrollView,
} from "react-native";
import { router, useFocusEffect } from "expo-router";
import { useAuth, brl, displayDate, today, cents } from "../core";
import type { PaymentMethod } from "../services/api";
import {
  Screen,
  Card,
  Title,
  Muted,
  Button,
  Field,
  Chips,
  Notice,
  s,
  colors,
  Icon,
  Segment,
  SectionHeading,
} from "../components/ui";
import {
  CalendarStrip,
  AppointmentRow,
  dateOf,
  shiftDay,
  longDay,
} from "../components/salon";
const labels: Record<string, string> = {
  aguardando_confirmacao: "Aguardando confirmação",
  confirmado: "Confirmado",
  em_atendimento: "Em atendimento",
  concluido: "Concluído",
  cancelado: "Cancelado",
  nao_compareceu: "Não compareceu",
};
export default function Appointments() {
  const { api, session } = useAuth();
  const admin = session?.user.role === "admin";
  const [rows, setRows] = useState<any[]>([]),
    [date, setDate] = useState(admin ? today() : ""),
    [error, setError] = useState(""),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [selected, setSelected] = useState(0),
    [amount, setAmount] = useState(""),
    [method, setMethod] = useState<PaymentMethod>("pix"),
    [newDate, setNewDate] = useState(""),
    [newSlot, setNewSlot] = useState(""),
    [slots, setSlots] = useState<any[]>([]);
  const [period, setPeriod] = useState("Dia"),
    [professional, setProfessional] = useState("Todas"),
    [detail, setDetail] = useState(0);
  const load = useCallback(async () => {
    if (!session) return;
    setBusy(true);
    try {
      setRows(
        await api.appointments.list(admin ? undefined : date || undefined),
      );
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }, [date, session, api, admin]);
  useFocusEffect(
    useCallback(() => {
      load();
    }, [load]),
  );
  async function act(operation: () => Promise<unknown>) {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      await operation();
      setMessage("Agendamento atualizado.");
      setSelected(0);
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function cancel(id: number) {
    if (Platform.OS === "web") {
      if (window.confirm("Cancelar este agendamento?"))
        act(() => api.appointments.cancel(id));
    } else
      Alert.alert(
        "Cancelar agendamento",
        "O horário será liberado para outras pessoas.",
        [
          { text: "Voltar", style: "cancel" },
          {
            text: "Cancelar horário",
            style: "destructive",
            onPress: () => act(() => api.appointments.cancel(id)),
          },
        ],
      );
  }
  async function pay(a: any) {
    setBusy(true);
    setError("");
    try {
      await api.payments.create({
        appointment_id: a.id,
        amount: cents(amount),
        method,
        request_key: `payment-${a.id}-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      });
      setAmount("");
      setSelected(0);
      setMessage("Pagamento registrado.");
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function available(a: any) {
    setBusy(true);
    try {
      setSlots(
        await api.availability({
          service_id: a.service_id,
          professional_id: a.professional_id,
          date: newDate,
        }),
      );
      setNewSlot("");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const currentDate = date || today();
  const weekday = (new Date(currentDate + "T12:00:00Z").getUTCDay() + 6) % 7;
  const rangeStart =
    period === "Semana"
      ? shiftDay(currentDate, -weekday)
      : period === "Mês"
        ? currentDate.slice(0, 7) + "-01"
        : currentDate;
  const rangeEnd =
    period === "Semana"
      ? shiftDay(rangeStart, 6)
      : period === "Mês"
        ? new Date(
            Number(currentDate.slice(0, 4)),
            Number(currentDate.slice(5, 7)),
            0,
            12,
          )
            .toISOString()
            .slice(0, 10)
        : currentDate;
  const visible = rows
    .filter(
      (a) =>
        (!admin ||
          (dateOf(a.start) >= rangeStart && dateOf(a.start) <= rangeEnd)) &&
        (professional === "Todas" || a.professional === professional),
    )
    .sort((a, b) => a.start.localeCompare(b.start));
  return (
    <Screen
      title={admin ? "Agenda" : "Meus horários"}
      subtitle={
        admin
          ? "Seus atendimentos, dia a dia"
          : "Seus próximos momentos de cuidado."
      }
      busy={busy}
    >
      <Notice error message={error} />
      <Notice message={message} />
      {admin && (
        <>
          <Segment
            items={["Dia", "Semana", "Mês"]}
            value={period}
            onSelect={setPeriod}
          />
          <CalendarStrip date={currentDate} onSelect={setDate} rows={rows} />
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 7, paddingVertical: 3 }}
          >
            {[
              "Todas",
              ...Array.from(new Set(rows.map((a) => String(a.professional)))),
            ].map((p) => (
              <Pressable
                key={p}
                accessibilityRole="button"
                onPress={() => setProfessional(p)}
                style={[
                  s.chip,
                  professional === p && { backgroundColor: colors.accent },
                ]}
              >
                <Text style={{ color: colors.text, fontSize: 14 }}>{p}</Text>
              </Pressable>
            ))}
          </ScrollView>
          <View style={s.row}>
            <Text style={[s.sectionTitle, { fontSize: 22, flex: 1 }]}>
              {period === "Dia"
                ? longDay(currentDate).replace(/^./, (v) => v.toUpperCase())
                : period === "Semana"
                  ? "Atendimentos da semana"
                  : "Atendimentos do mês"}
            </Text>
            <Text style={s.muted}>{visible.length} atendimentos</Text>
          </View>
        </>
      )}
      {!!visible.length && (
        <Card style={{ padding: 0, gap: 0 }}>
          {visible.map((a, i) => (
            <View key={a.id}>
              {admin &&
                period !== "Dia" &&
                (i === 0 ||
                  dateOf(a.start) !== dateOf(visible[i - 1].start)) && (
                  <Text style={[s.caption, { padding: 14 }]}>
                    {longDay(dateOf(a.start))}
                  </Text>
                )}
              <AppointmentRow
                a={a}
                status
                last={i === visible.length - 1}
                onPress={() => setDetail(a.id)}
              />
            </View>
          ))}
        </Card>
      )}
      {admin && (
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push("/booking")}
          style={{
            alignSelf: "flex-end",
            flexDirection: "row",
            gap: 6,
            alignItems: "center",
          }}
        >
          <Icon name="add-circle-outline" />
          <Text style={{ color: colors.accent }}>Novo agendamento</Text>
        </Pressable>
      )}
      {!visible.length && !busy && (
        <Card>
          <Title>Nenhum agendamento</Title>
          <Muted>Seus horários aparecerão aqui após a reserva.</Muted>
        </Card>
      )}
      <Modal
        visible={detail > 0}
        transparent
        animationType="slide"
        onRequestClose={() => setDetail(0)}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "#000000B8",
            justifyContent: "flex-end",
          }}
        >
          <View
            style={{
              backgroundColor: colors.bg,
              maxHeight: "88%",
              borderTopLeftRadius: 26,
              borderTopRightRadius: 26,
              padding: 18,
            }}
          >
            <View style={[s.row, { marginBottom: 16 }]}>
              <SectionHeading title="Atendimento" />
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Fechar detalhes"
                onPress={() => setDetail(0)}
              >
                <Icon name="close" size={26} />
              </Pressable>
            </View>
            <ScrollView
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ paddingBottom: 24 }}
            >
              {rows
                .filter((a) => a.id === detail)
                .map((a) => (
                  <Card key={a.id}>
                    <View style={s.row}>
                      <Text style={s.badge}>
                        {labels[a.status] || a.status}
                      </Text>
                      <Text style={s.muted}>#{a.id}</Text>
                    </View>
                    <Title>{a.service_name}</Title>
                    <Text style={{ color: "#f5eff2", fontSize: 21 }}>
                      {displayDate(a.start)}
                    </Text>
                    <Muted>
                      {a.professional}
                      {admin ? ` · ${a.client}` : ""}
                    </Muted>
                    <View style={s.row}>
                      <Text style={s.title}>{brl(a.price)}</Text>
                      <Muted>
                        {a.paid >= a.price
                          ? "Pago"
                          : `Pendente ${brl(a.price - a.paid)}`}
                      </Muted>
                    </View>
                    {a.notes && <Muted>{a.notes}</Muted>}
                    {admin && (
                      <Button
                        secondary
                        title="Abrir comanda / estornos"
                        onPress={() => (
                          setDetail(0),
                          router.push({
                            pathname: "/order",
                            params: { id: String(a.id) },
                          })
                        )}
                      />
                    )}
                    {["confirmado", "aguardando_confirmacao"].includes(
                      a.status,
                    ) && (
                      <View style={{ gap: 8 }}>
                        <Button
                          secondary
                          title="Reagendar"
                          onPress={() => {
                            setSelected(selected === a.id ? 0 : a.id);
                            setNewDate(today());
                            setSlots([]);
                          }}
                        />
                        <Button
                          secondary
                          title="Cancelar horário"
                          onPress={() => cancel(a.id)}
                        />
                      </View>
                    )}
                    {admin && a.status === "confirmado" && (
                      <>
                        <Button
                          title="Iniciar atendimento"
                          onPress={() =>
                            act(() =>
                              api.appointments.updateStatus(
                                a.id,
                                "em_atendimento",
                              ),
                            )
                          }
                        />
                        <Button
                          secondary
                          title="Marcar ausência"
                          onPress={() =>
                            act(() =>
                              api.appointments.updateStatus(
                                a.id,
                                "nao_compareceu",
                              ),
                            )
                          }
                        />
                      </>
                    )}
                    {admin && a.status === "em_atendimento" && (
                      <Button
                        title="Concluir atendimento"
                        onPress={() =>
                          act(() =>
                            api.appointments.updateStatus(a.id, "concluido"),
                          )
                        }
                      />
                    )}{" "}
                    {admin &&
                      !["cancelado", "nao_compareceu"].includes(a.status) &&
                      a.paid < a.price && (
                        <Button
                          secondary
                          title="Registrar pagamento / sinal"
                          onPress={() => {
                            setSelected(a.id);
                            setAmount(((a.price - a.paid) / 100).toFixed(2));
                            setSlots([]);
                          }}
                        />
                      )}
                    {selected === a.id && (
                      <View style={{ gap: 12 }}>
                        {admin && (
                          <>
                            <Field
                              label="Valor recebido (R$)"
                              value={amount}
                              onChangeText={setAmount}
                              numeric
                            />
                            <Chips
                              items={[
                                "pix",
                                "dinheiro",
                                "debito",
                                "credito",
                              ].map((x) => ({ id: x, label: x }))}
                              value={method}
                              onSelect={setMethod}
                            />
                            <Button
                              title="Confirmar recebimento"
                              disabled={busy || !amount}
                              onPress={() => pay(a)}
                            />
                          </>
                        )}
                        {["confirmado", "aguardando_confirmacao"].includes(
                          a.status,
                        ) && (
                          <>
                            <Field
                              label="Nova data (AAAA-MM-DD)"
                              value={newDate}
                              onChangeText={setNewDate}
                            />
                            <Button
                              secondary
                              title="Buscar novos horários"
                              onPress={() => available(a)}
                            />
                            <Chips
                              items={slots.map((x) => ({
                                id: x.start,
                                label: x.label,
                              }))}
                              value={newSlot}
                              onSelect={setNewSlot}
                            />
                            <Button
                              title="Confirmar novo horário"
                              disabled={!newSlot || busy}
                              onPress={() =>
                                act(() =>
                                  api.appointments.reschedule(a.id, newSlot),
                                )
                              }
                            />
                          </>
                        )}
                      </View>
                    )}
                  </Card>
                ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </Screen>
  );
}
