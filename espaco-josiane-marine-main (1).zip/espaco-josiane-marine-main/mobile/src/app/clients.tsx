import React, { useState, useCallback } from "react";
import { View, Text, TextInput, Pressable } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { useAuth } from "../core";
import {
  Screen,
  Card,
  Muted,
  Button,
  Notice,
  Icon,
  IconCircle,
  colors,
  s,
} from "../components/ui";
export default function Clients() {
  const { api, session } = useAuth();
  const [clients, setClients] = useState<any[]>([]),
    [search, setSearch] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  useFocusEffect(
    useCallback(() => {
      if (session?.user.role !== "admin") return;
      setBusy(true);
      api.users
        .clients()
        .then(setClients)
        .catch((e) => setError(e.message))
        .finally(() => setBusy(false));
    }, [api, session?.user.role]),
  );
  const visible = clients.filter((c) =>
    `${c.name} ${c.email} ${c.phone}`
      .toLowerCase()
      .includes(search.toLowerCase()),
  );
  return (
    <Screen
      admin
      title="Clientes"
      subtitle="Cuidado que começa com uma conexão"
      busy={busy}
    >
      <Notice error message={error} />
      <Card style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
        <Icon name="search-outline" color={colors.muted} />
        <TextInput
          accessibilityLabel="Buscar clientes"
          placeholder="Buscar nome, telefone ou e-mail"
          placeholderTextColor={colors.muted}
          value={search}
          onChangeText={setSearch}
          style={{
            flex: 1,
            color: colors.text,
            fontSize: 14,
            paddingVertical: 4,
          }}
        />
      </Card>
      <View style={s.row}>
        <Muted>{visible.length} clientes</Muted>
        <Pressable
          accessibilityRole="button"
          onPress={() => router.push("/manage")}
        >
          <Text style={{ color: colors.accent }}>Gestão do salão</Text>
        </Pressable>
      </View>
      <Card style={{ padding: 0, gap: 0 }}>
        {visible.map((c, i) => (
          <View
            key={c.id}
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 12,
              padding: 16,
              borderBottomWidth: i === visible.length - 1 ? 0 : 1,
              borderColor: colors.border,
            }}
          >
            <IconCircle name="person-outline" />
            <View style={{ flex: 1, gap: 5 }}>
              <Text style={{ color: colors.text, fontSize: 16 }}>{c.name}</Text>
              <Muted>{c.phone || c.email}</Muted>
            </View>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Agendar para ${c.name}`}
              onPress={() =>
                router.push({
                  pathname: "/booking",
                  params: { clientId: String(c.id) },
                })
              }
            >
              <Icon name="calendar-outline" />
            </Pressable>
          </View>
        ))}
        {!visible.length && (
          <View style={{ padding: 20 }}>
            <Muted>
              {search
                ? "Nenhum cliente encontrado."
                : "Os clientes aparecerão após criarem suas contas."}
            </Muted>
          </View>
        )}
      </Card>
      <Button
        secondary
        title="Serviços, profissionais e horários"
        onPress={() => router.push("/manage")}
      />
    </Screen>
  );
}
