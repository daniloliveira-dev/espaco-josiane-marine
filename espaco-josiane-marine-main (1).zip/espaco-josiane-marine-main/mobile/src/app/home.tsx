import React, { useState, useCallback } from "react";
import { Text, View, Pressable } from "react-native";
import { router, useFocusEffect } from "expo-router";
import { useAuth, brl, today } from "../core";
import {
  Screen,
  Card,
  Muted,
  Notice,
  SectionHeading,
  IconCircle,
  Icon,
  colors,
  s,
} from "../components/ui";
import { Metric, Gauge, AppointmentRow, percentage } from "../components/salon";
export default function Home() {
  const { session, api } = useAuth();
  const [data, setData] = useState<any>(null),
    [cash, setCash] = useState<any>(null),
    [expenses, setExpenses] = useState<any[]>([]),
    [appointments, setAppointments] = useState<any[]>([]),
    [error, setError] = useState("");
  useFocusEffect(
    useCallback(() => {
      if (session?.user.role !== "admin") return;
      let active = true;
      setError("");
      Promise.all([
        api.reports.get(today(), today()),
        api.cash.list(),
        api.appointments.list(today()),
        api.expenses.list(),
      ])
        .then(([r, c, a, e]) => {
          if (active) {
            setData(r);
            setCash(c.find((x: any) => x.date === today()));
            setAppointments(a);
            setExpenses(e);
          }
        })
        .catch((e) => {
          if (active) setError(e.message);
        });
      return () => {
        active = false;
      };
    }, [session?.user.role, api]),
  );
  const now = new Date();
  const hour = Number(
    now.toLocaleTimeString("en-GB", {
      timeZone: "America/Sao_Paulo",
      hour: "2-digit",
      hour12: false,
    }),
  );
  const greeting =
    hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";
  const next = appointments
    .filter(
      (a) => !["cancelado", "concluido", "nao_compareceu"].includes(a.status),
    )
    .sort((a, b) => a.start.localeCompare(b.start));
  const expected =
    cash?.expected ??
    (cash?.initial || 0) +
      (data?.byMethod?.dinheiro || 0) -
      expenses
        .filter((e) => e.date === today() && e.method === "dinheiro")
        .reduce((n, e) => n + e.amount, 0);
  const progress = percentage(
    appointments.filter((a) => a.status === "concluido").length,
    appointments.filter(
      (a) => !["cancelado", "nao_compareceu"].includes(a.status),
    ).length,
  );
  const cashLabels: Record<string, string> = {
    aberto: "Caixa aberto",
    aguardando_conferencia: "Aguardando conferência",
    fechado: "Caixa fechado",
    conferido: "Caixa conferido",
  };
  return (
    <Screen
      admin
      title={`${greeting}, ${session?.user.name.split(" ")[0] || "Josiane"}`}
      subtitle={now.toLocaleDateString("pt-BR", {
        timeZone: "America/Sao_Paulo",
        weekday: "long",
        day: "numeric",
        month: "long",
      })}
      busy={!data && !error}
    >
      <Notice error message={error} />
      <View style={[s.wrap, { gap: 8 }]}>
        <Metric
          label="Serviços realizados"
          value={data?.revenue || 0}
          hint={`${data?.attendances || 0} atendimentos`}
          icon="cut-outline"
          onPress={() => router.push("/reports")}
        />
        <Metric
          label="Recebido"
          value={data?.received || 0}
          hint={`${percentage(data?.received || 0, data?.revenue || 0)}% do dia`}
          icon="wallet"
          accent
          onPress={() => router.push("/cash")}
        />
        <Metric
          label="Pendente"
          value={data?.outstanding || 0}
          hint={`${appointments.filter((a) => a.paid < a.price && !["cancelado", "nao_compareceu"].includes(a.status)).length} atendimentos`}
          icon="time-outline"
          tone={colors.amber}
          onPress={() => router.push("/appointments")}
        />
        <Metric
          label="Despesas"
          value={data?.expenses || 0}
          hint={`${percentage(data?.expenses || 0, data?.received || 0)}% da receita`}
          icon="bar-chart"
          tone="#AAA7B0"
          onPress={() => router.push("/cash")}
        />
      </View>
      <Pressable
        accessibilityRole="button"
        onPress={() => router.push("/cash")}
      >
        <Card
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 12,
            paddingVertical: 6,
          }}
        >
          <IconCircle name="calculator" size={48} />
          <View style={{ flex: 1, gap: 6 }}>
            <Text
              style={{ color: colors.text, fontSize: 16, fontWeight: "500" }}
            >
              {cash
                ? cashLabels[cash.status] || "Caixa do dia"
                : "Caixa não aberto"}
            </Text>
            <Muted>Dinheiro esperado</Muted>
            <Text style={{ color: colors.text, fontSize: 16 }}>
              {brl(expected)}
            </Text>
          </View>
          <Gauge value={progress} />
          <Icon name="chevron-forward" color={colors.muted} size={18} />
        </Card>
      </Pressable>
      <SectionHeading
        title="Próximos atendimentos"
        action="Ver todos"
        onPress={() => router.push("/appointments")}
      />
      <Card style={{ padding: 0, gap: 0 }}>
        {next.length ? (
          next
            .slice(0, 4)
            .map((a, i) => (
              <AppointmentRow
                key={a.id}
                a={a}
                last={i === Math.min(next.length, 4) - 1}
                onPress={() =>
                  router.push({
                    pathname: "/order",
                    params: { id: String(a.id) },
                  })
                }
              />
            ))
        ) : (
          <View style={{ padding: 20 }}>
            <Muted>Nenhum atendimento pendente hoje.</Muted>
          </View>
        )}
      </Card>
    </Screen>
  );
}
