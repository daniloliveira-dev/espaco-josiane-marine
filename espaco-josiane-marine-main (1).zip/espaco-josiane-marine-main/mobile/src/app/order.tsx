import React, { useState, useCallback, useRef } from "react";
import { Text, View, Pressable, Modal, ScrollView } from "react-native";
import { useLocalSearchParams, useFocusEffect } from "expo-router";
import { useAuth, brl, cents } from "../core";
import type { PaymentMethod } from "../services/api";
import {
  Screen,
  Card,
  Title,
  Muted,
  Field,
  Button,
  Chips,
  Notice,
  IconCircle,
  Icon,
  colors,
  s,
} from "../components/ui";
import { dateOf } from "../components/salon";
const methodNames: Record<PaymentMethod, string> = {
  pix: "Pix",
  dinheiro: "Dinheiro",
  debito: "Débito",
  credito: "Crédito",
};
export default function Order() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { api, session } = useAuth();
  const [data, setData] = useState<any>(null),
    [products, setProducts] = useState<any[]>([]),
    [services, setServices] = useState<any[]>([]),
    [kind, setKind] = useState<"produto" | "servico">("produto"),
    [item, setItem] = useState(0),
    [quantity, setQuantity] = useState("1"),
    [discount, setDiscount] = useState("0"),
    [extra, setExtra] = useState("0"),
    [reason, setReason] = useState(""),
    [payment, setPayment] = useState(0),
    [refund, setRefund] = useState(""),
    [refundReason, setRefundReason] = useState(""),
    [error, setError] = useState(""),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [panel, setPanel] = useState(""),
    [method, setMethod] = useState<PaymentMethod>("pix"),
    [amount, setAmount] = useState(""),
    [paid, setPaid] = useState(0);
  const pendingKey = useRef<{
    amount: number;
    method: PaymentMethod;
    key: string;
  } | null>(null);
  const load = useCallback(async () => {
    if (session?.user.role !== "admin" || !id) return;
    const [a, b, c] = await Promise.all([
      api.appointments.order(Number(id)),
      api.products.list(),
      api.services.list(),
    ]);
    const rows = await api.appointments.list(dateOf(a.appointment.start));
    const entry = rows.find((x: any) => x.id === Number(id));
    if (!entry)
      throw Error("Não foi possível conferir o saldo deste atendimento.");
    setPaid(entry.paid);
    setData(a);
    setProducts(b);
    setServices(c);
    setDiscount(((a.adjustment?.discount || 0) / 100).toFixed(2));
    setExtra(((a.adjustment?.extra || 0) / 100).toFixed(2));
    setReason(a.adjustment?.reason || "");
    setAmount((Math.max(0, a.appointment.price - entry.paid) / 100).toFixed(2));
  }, [api, session?.user.role, id]);
  useFocusEffect(
    useCallback(() => {
      void load().catch((e) => setError(e.message));
    }, [load]),
  );
  async function action(fn: () => Promise<unknown>) {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      await fn();
      setMessage("Comanda atualizada.");
      await load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const editable =
    data &&
    ["confirmado", "em_atendimento", "aguardando_confirmacao"].includes(
      data.appointment.status,
    );
  const balance = Math.max(0, (data?.appointment.price || 0) - paid);
  async function receive(finalize: boolean) {
    if (!data || busy) return;
    setBusy(true);
    setError("");
    setMessage("");
    try {
      if (balance > 0) {
        const value = cents(amount);
        if (value <= 0 || value > balance)
          throw Error("Informe um valor entre R$ 0,01 e o saldo pendente.");
        if (finalize && value !== balance)
          throw Error(
            "Para finalizar e receber, informe o saldo pendente completo. Para um sinal, use Registrar pagamento.",
          );
        if (
          !pendingKey.current ||
          pendingKey.current.amount !== value ||
          pendingKey.current.method !== method
        )
          pendingKey.current = {
            amount: value,
            method,
            key: `order-${id}-${Date.now()}-${Math.random().toString(36).slice(2)}`,
          };
        await api.payments.create({
          appointment_id: Number(id),
          amount: value,
          method,
          request_key: pendingKey.current.key,
        });
        pendingKey.current = null;
      }
      if (finalize) {
        let status = data.appointment.status;
        if (status === "aguardando_confirmacao") {
          await api.appointments.updateStatus(Number(id), "confirmado");
          status = "confirmado";
        }
        if (status === "confirmado") {
          await api.appointments.updateStatus(Number(id), "em_atendimento");
          status = "em_atendimento";
        }
        if (status === "em_atendimento")
          await api.appointments.updateStatus(Number(id), "concluido");
      }
      setMessage(
        finalize
          ? "Atendimento finalizado e pagamento registrado."
          : "Pagamento registrado.",
      );
      setPanel("");
      await load();
    } catch (e) {
      setError((e as Error).message);
      try {
        await load();
      } catch {}
    } finally {
      setBusy(false);
    }
  }
  const payAllowed =
    data && !["cancelado", "nao_compareceu"].includes(data.appointment.status);
  return (
    <Screen
      admin
      title="Comanda"
      back="Agenda"
      hideNav
      busy={busy || (!data && !error)}
    >
      <Notice error message={error} />
      <Notice message={message} />
      {data && (
        <>
          <Card style={{ paddingHorizontal: 0, gap: 0 }}>
            <View style={{ paddingHorizontal: 20, paddingBottom: 8 }}>
              <Text style={s.caption}>SERVIÇOS E PRODUTOS</Text>
            </View>
            {data.items.map((x: any, i: number) => (
              <Pressable
                key={x.id}
                accessibilityRole="button"
                onPress={() => setPanel("items")}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 14,
                  paddingHorizontal: 16,
                  paddingVertical: 6,
                }}
              >
                <IconCircle
                  name={
                    x.kind === "produto"
                      ? "flask-outline"
                      : "color-palette-outline"
                  }
                  size={44}
                />
                <View
                  style={[
                    s.row,
                    {
                      flex: 1,
                      paddingVertical: 12,
                      borderTopWidth: i === 0 ? 0 : 1,
                      borderColor: colors.border,
                    },
                  ]}
                >
                  <Text style={{ color: colors.text, fontSize: 16, flex: 1 }}>
                    {x.name}
                    {x.quantity > 1 ? ` × ${x.quantity}` : ""}
                  </Text>
                  <Text style={{ color: colors.text, fontSize: 16 }}>
                    {brl(x.unit_price * x.quantity)}
                  </Text>
                  <Icon name="chevron-forward" color="#706C75" size={18} />
                </View>
              </Pressable>
            ))}
          </Card>
          <Card style={{ paddingHorizontal: 0, gap: 0 }}>
            <Text
              style={[s.caption, { paddingHorizontal: 20, paddingBottom: 8 }]}
            >
              TOTAIS
            </Text>
            {[
              ["Total", data.appointment.price],
              ["Sinal pago", -paid],
              ["Saldo pendente", balance],
            ].map(([label, value], i) => (
              <View
                key={String(label)}
                style={[
                  s.row,
                  {
                    paddingHorizontal: 20,
                    paddingVertical: 11,
                    borderTopWidth: i === 0 ? 0 : 1,
                    borderColor: colors.border,
                  },
                ]}
              >
                <Text
                  style={{
                    color: i ? colors.muted : colors.text,
                    fontSize: 16,
                  }}
                >
                  {label}
                </Text>
                <Text
                  style={{
                    color:
                      i === 2
                        ? colors.accent
                        : i === 1
                          ? colors.muted
                          : colors.text,
                    fontSize: 17,
                    fontWeight: i === 1 ? "400" : "600",
                  }}
                >
                  {Number(value) < 0 ? "−" : ""}
                  {brl(Math.abs(Number(value)))}
                </Text>
              </View>
            ))}
          </Card>
          <Card style={{ paddingHorizontal: 0, gap: 0 }}>
            <Text
              style={[s.caption, { paddingHorizontal: 20, paddingBottom: 8 }]}
            >
              FORMA DE PAGAMENTO
            </Text>
            <Pressable
              accessibilityRole="button"
              onPress={() => setPanel("payment")}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 14,
                paddingHorizontal: 16,
                paddingVertical: 12,
              }}
            >
              <IconCircle
                name={
                  method === "pix"
                    ? "diamond-outline"
                    : method === "dinheiro"
                      ? "cash"
                      : "card-outline"
                }
                tone={method === "pix" ? "#BDB5C4" : colors.accent}
                size={44}
              />
              <Text style={{ color: colors.text, fontSize: 16, flex: 1 }}>
                {methodNames[method]}
              </Text>
              <Text style={{ color: colors.text, fontSize: 16 }}>
                {brl(Number(amount.replace(",", ".")) * 100 || 0)}
              </Text>
              <Icon name="chevron-forward" color={colors.muted} size={18} />
            </Pressable>
            {data.payments.length > 0 && (
              <Pressable
                accessibilityRole="button"
                onPress={() => setPanel("refund")}
                style={[
                  s.row,
                  {
                    padding: 16,
                    borderTopWidth: 1,
                    borderColor: colors.border,
                  },
                ]}
              >
                <Muted>{data.payments.length} pagamento(s) registrado(s)</Muted>
                <Icon name="chevron-forward" color={colors.muted} size={18} />
              </Pressable>
            )}
          </Card>
          {payAllowed && (balance > 0 || editable) && (
            <View style={{ marginTop: 12 }}>
              <Button
                title={
                  balance > 0 ? "Finalizar e receber" : "Finalizar atendimento"
                }
                disabled={busy}
                onPress={() => receive(true)}
              />
            </View>
          )}
          <View
            style={[
              s.row,
              { justifyContent: "center", gap: 24, paddingVertical: 4 },
            ]}
          >
            {editable && (
              <Pressable
                accessibilityRole="button"
                onPress={() => setPanel("items")}
              >
                <Text style={{ color: colors.accent, fontSize: 13 }}>
                  Editar comanda
                </Text>
              </Pressable>
            )}
            {payAllowed && balance > 0 && (
              <Pressable
                accessibilityRole="button"
                onPress={() => setPanel("payment")}
              >
                <Text style={{ color: colors.accent, fontSize: 13 }}>
                  Registrar pagamento
                </Text>
              </Pressable>
            )}
          </View>
        </>
      )}
      <Modal
        visible={!!panel}
        transparent
        animationType="slide"
        onRequestClose={() => setPanel("")}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "#000000B8",
            justifyContent: "flex-end",
          }}
        >
          <View
            style={{
              backgroundColor: colors.bg,
              maxHeight: "90%",
              padding: 20,
              borderTopLeftRadius: 24,
              borderTopRightRadius: 24,
            }}
          >
            <View style={[s.row, { marginBottom: 16 }]}>
              <Title>
                {panel === "payment"
                  ? "Recebimento"
                  : panel === "refund"
                    ? "Pagamentos e estornos"
                    : "Editar comanda"}
              </Title>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Fechar"
                onPress={() => setPanel("")}
              >
                <Icon name="close" size={25} />
              </Pressable>
            </View>
            <ScrollView
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ gap: 16, paddingBottom: 24 }}
            >
              <Notice error message={error} />
              <Notice message={message} />
              {panel === "payment" && (
                <Card>
                  <Muted>Saldo pendente: {brl(balance)}</Muted>
                  <Chips
                    items={Object.entries(methodNames).map(([id, label]) => ({
                      id,
                      label,
                    }))}
                    value={method}
                    onSelect={setMethod}
                  />
                  <Field
                    label="Valor a receber (R$)"
                    value={amount}
                    onChangeText={setAmount}
                    numeric
                  />
                  <Button
                    title="Registrar pagamento"
                    disabled={busy || !payAllowed || balance === 0}
                    onPress={() => receive(false)}
                  />
                  <Button
                    secondary
                    title="Usar esta forma ao finalizar"
                    onPress={() => setPanel("")}
                  />
                </Card>
              )}
              {panel === "items" && data && (
                <>
                  {data.items.map((x: any) => (
                    <Card key={x.id}>
                      <View style={s.row}>
                        <Title>
                          {x.name} × {x.quantity}
                        </Title>
                        <Muted>{brl(x.unit_price * x.quantity)}</Muted>
                      </View>
                      {editable && x.kind === "produto" && (
                        <Button
                          secondary
                          title="Remover produto"
                          disabled={busy}
                          onPress={() =>
                            action(() =>
                              api.appointments.removeOrderItem(
                                Number(id),
                                x.id,
                              ),
                            )
                          }
                        />
                      )}
                    </Card>
                  ))}
                  {editable && (
                    <>
                      <Card>
                        <Title>Adicionar à comanda</Title>
                        <Chips
                          items={[
                            { id: "produto", label: "Produto" },
                            { id: "servico", label: "Serviço adicional" },
                          ]}
                          value={kind}
                          onSelect={(v) => {
                            setKind(v);
                            setItem(0);
                          }}
                        />
                        <Chips
                          items={(kind === "produto" ? products : services)
                            .filter((x) => x.active)
                            .map((x) => ({
                              id: x.id,
                              label: `${x.name} · ${brl(x.price)}`,
                            }))}
                          value={item}
                          onSelect={setItem}
                        />
                        <Field
                          label="Quantidade"
                          value={quantity}
                          onChangeText={setQuantity}
                          numeric
                        />
                        <Button
                          title="Adicionar item"
                          disabled={!item || busy}
                          onPress={() =>
                            action(() =>
                              api.appointments.addOrderItem(Number(id), {
                                kind,
                                item_id: item,
                                quantity: Number(quantity),
                              }),
                            )
                          }
                        />
                      </Card>
                      <Card>
                        <Title>Desconto ou acréscimo</Title>
                        <Field
                          label="Desconto (R$)"
                          value={discount}
                          onChangeText={setDiscount}
                          numeric
                        />
                        <Field
                          label="Acréscimo (R$)"
                          value={extra}
                          onChangeText={setExtra}
                          numeric
                        />
                        <Field
                          label="Justificativa"
                          value={reason}
                          onChangeText={setReason}
                        />
                        <Button
                          title="Aplicar ajuste"
                          disabled={busy}
                          onPress={() =>
                            action(() =>
                              api.appointments.updateOrderAdjustment(
                                Number(id),
                                {
                                  discount: cents(discount),
                                  extra: cents(extra),
                                  reason,
                                },
                              ),
                            )
                          }
                        />
                      </Card>
                    </>
                  )}
                </>
              )}
              {panel === "refund" && data && (
                <>
                  <Card>
                    <Title>Pagamentos registrados</Title>
                    {data.payments.map((p: any) => (
                      <View style={s.row} key={p.id}>
                        <Muted>
                          #{p.id} ·{" "}
                          {methodNames[p.method as PaymentMethod] || p.method}
                        </Muted>
                        <Title>{brl(p.amount)}</Title>
                      </View>
                    ))}
                  </Card>
                  <Card>
                    <Title>Registrar estorno</Title>
                    <Chips
                      items={data.payments.map((p: any) => ({
                        id: p.id,
                        label: `#${p.id} ${p.method} · ${brl(p.amount)}`,
                      }))}
                      value={payment}
                      onSelect={setPayment}
                    />
                    <Field
                      label="Valor a estornar (R$)"
                      value={refund}
                      onChangeText={setRefund}
                      numeric
                    />
                    <Field
                      label="Motivo"
                      value={refundReason}
                      onChangeText={setRefundReason}
                    />
                    <Button
                      title="Confirmar estorno"
                      disabled={!payment || busy}
                      onPress={() =>
                        action(() =>
                          api.refunds.create({
                            payment_id: payment,
                            amount: cents(refund),
                            reason: refundReason,
                            request_key: `refund-${payment}-${Date.now()}`,
                          }),
                        )
                      }
                    />
                    <Muted>
                      Realize também a devolução na instituição de pagamento.
                    </Muted>
                  </Card>
                </>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </Screen>
  );
}
