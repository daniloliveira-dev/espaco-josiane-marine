import { useFocusEffect } from "expo-router";
import React, { useState, useCallback } from "react";
import {
  Platform,
  Text,
  View,
  Pressable,
  Modal,
  ScrollView,
} from "react-native";
import { File, Paths } from "expo-file-system";
import * as Sharing from "expo-sharing";
import { useAuth, brl, today } from "../core";
import {
  Screen,
  Card,
  Title,
  Muted,
  Field,
  Button,
  Notice,
  s,
  Icon,
  colors,
  Segment,
} from "../components/ui";
import { Metric, RevenueChart, percentage } from "../components/salon";
export default function Reports() {
  const { api, session } = useAuth();
  const [from, setFrom] = useState(today().slice(0, 7) + "-01"),
    [to, setTo] = useState(today()),
    [data, setData] = useState<any>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [months, setMonths] = useState<any[]>([]),
    [panel, setPanel] = useState(""),
    [professional, setProfessional] = useState("Todos os profissionais"),
    [pros, setPros] = useState<any[]>([]),
    [chartMode, setChartMode] = useState("Dia"),
    [showAll, setShowAll] = useState(false),
    [previous, setPrevious] = useState<any>(null),
    [draftFrom, setDraftFrom] = useState(from),
    [draftTo, setDraftTo] = useState(to);
  const load = useCallback(async () => {
    if (session?.user.role !== "admin") return;
    setBusy(true);
    setError("");
    try {
      if (
        !/^\d{4}-\d{2}-\d{2}$/.test(from) ||
        !/^\d{4}-\d{2}-\d{2}$/.test(to) ||
        from > to
      )
        throw Error("Informe um período válido.");
      const [report, monthly, professionals] = await Promise.all([
        api.reports.get(from, to),
        api.reports.monthly(),
        api.professionals.list(),
      ]);
      setData(report);
      setMonths(monthly);
      setPros(professionals);
      const start = new Date(from + "T12:00:00Z");
      const previousStart = new Date(
        Date.UTC(start.getUTCFullYear(), start.getUTCMonth() - 1, 1, 12),
      );
      const previousEnd = new Date(
        Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), 0, 12),
      );
      try {
        setPrevious(
          await api.reports.get(
            previousStart.toISOString().slice(0, 10),
            previousEnd.toISOString().slice(0, 10),
          ),
        );
      } catch {
        setPrevious(null);
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }, [api, session?.user.role, from, to]);
  useFocusEffect(
    useCallback(() => {
      void load().catch((e) => setError(e.message));
    }, [load]),
  );
  async function download(format: string) {
    setBusy(true);
    setError("");
    try {
      const bytes = new Uint8Array(
        await api.reports.export(
          data?.from || from,
          data?.to || to,
          format as "csv" | "pdf",
        ),
      );
      const name = `relatorio-${data?.from || from}-${data?.to || to}.${format}`;
      if (Platform.OS === "web") {
        const blob = new Blob([bytes], {
          type: format === "pdf" ? "application/pdf" : "text/csv",
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = name;
        a.click();
        URL.revokeObjectURL(url);
      } else {
        const file = new File(Paths.cache, name);
        file.create({ overwrite: true });
        file.write(bytes);
        if (await Sharing.isAvailableAsync())
          await Sharing.shareAsync(file.uri, {
            mimeType: format === "pdf" ? "application/pdf" : "text/csv",
          });
        else throw Error("Compartilhamento indisponível neste aparelho");
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const grouped: Record<
    string,
    { name: string; count: number; total: number }
  > = {};
  data?.appointments
    .filter(
      (a: any) =>
        a.status === "concluido" &&
        (professional === "Todos os profissionais" ||
          a.professional === professional),
    )
    .forEach((a: any) => {
      const key = a.service_name;
      grouped[key] ??= { name: key, count: 0, total: 0 };
      grouped[key].count++;
      grouped[key].total += a.price;
    });
  const entries = (data?.appointments || []).filter(
    (a: any) =>
      professional === "Todos os profissionais" ||
      a.professional === professional,
  );
  const ranking = Object.values(grouped).sort((a, b) => b.total - a.total);
  const growth =
    previous?.revenue > 0
      ? (((data?.revenue || 0) - previous.revenue) / previous.revenue) * 100
      : null;
  const growthLabel =
    growth === null
      ? "Sem comparação anterior"
      : `${growth >= 0 ? "+" : ""}${growth.toLocaleString("pt-BR", { maximumFractionDigits: 1 })}% vs ${new Date((previous?.from || from) + "T12:00:00Z").toLocaleDateString("pt-BR", { month: "long" })}`;
  const monthLabel = new Date(from + "T12:00:00Z")
    .toLocaleDateString("pt-BR", { month: "long", year: "numeric" })
    .replace(/^./, (v) => v.toUpperCase());
  const choices = Array.from(
    new Set([
      today().slice(0, 7),
      ...months.map((m) => m.month),
      ...Array.from({ length: 12 }, (_, i) => {
        const now = new Date(today() + "T12:00:00Z");
        return new Date(
          Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1, 12),
        )
          .toISOString()
          .slice(0, 7);
      }),
    ]),
  )
    .sort()
    .reverse();
  return (
    <Screen
      admin
      title="Relatórios"
      subtitle="Acompanhe o desempenho do seu salão"
      busy={busy}
    >
      <Notice error message={error} />
      <View style={[s.row, { gap: 9 }]}>
        {[
          { label: monthLabel, icon: "calendar-outline", panel: "period" },
          {
            label: professional,
            icon: "people-outline",
            panel: "professionals",
          },
        ].map((x) => (
          <Pressable
            accessibilityRole="button"
            key={x.panel}
            accessibilityLabel={x.label}
            onPress={() => {
              setDraftFrom(from);
              setDraftTo(to);
              setPanel(x.panel);
            }}
            style={{ flex: 1 }}
          >
            <Card
              style={{
                padding: 12,
                flexDirection: "row",
                alignItems: "center",
                gap: 8,
                borderRadius: 15,
              }}
            >
              <Icon name={x.icon as any} size={18} />
              <Text
                numberOfLines={1}
                adjustsFontSizeToFit
                style={{ color: colors.text, fontSize: 11, flex: 1 }}
              >
                {x.label}
              </Text>
              <Icon name="chevron-down" size={15} color={colors.muted} />
            </Card>
          </Pressable>
        ))}
      </View>
      <View style={[s.wrap, { gap: 8 }]}>
        <Metric
          label="Faturamento"
          value={data?.revenue || 0}
          hint={growthLabel}
          icon="bar-chart"
        />
        <Metric
          label="Recebido"
          value={data?.received || 0}
          hint={`${percentage(data?.received || 0, data?.revenue || 0)}% do faturamento`}
          icon="wallet"
          tone="#95C969"
        />
        <Metric
          label="Pendente"
          value={data?.outstanding || 0}
          hint={`${percentage(data?.outstanding || 0, data?.revenue || 0)}% do faturamento`}
          icon="time-outline"
          tone={colors.amber}
        />
        <Metric
          label="Resultado"
          value={data?.result || 0}
          hint={`${percentage(data?.result || 0, data?.received || 0)}% dos recebimentos`}
          icon="bar-chart"
          tone={colors.muted}
        />
      </View>
      {professional !== "Todos os profissionais" && (
        <Muted>
          Gráfico e serviços: {professional}. Indicadores financeiros: total do
          salão.
        </Muted>
      )}
      <Card style={{ gap: 8 }}>
        <View style={s.row}>
          <Text
            style={{
              color: colors.text,
              fontSize: 14,
              fontWeight: "600",
              flex: 1,
            }}
          >
            Faturamento{" "}
            {chartMode === "Dia"
              ? "diário"
              : chartMode === "Semana"
                ? "semanal"
                : "mensal"}
          </Text>
          <View style={{ width: 148 }}>
            <Segment
              small
              items={["Dia", "Semana", "Mês"]}
              value={chartMode}
              onSelect={setChartMode}
            />
          </View>
        </View>
        <Text style={{ color: colors.accent, fontSize: 13 }}>
          {growthLabel}
        </Text>
        <RevenueChart
          entries={entries}
          from={data?.from || from}
          to={data?.to || to}
          mode={chartMode}
        />
      </Card>
      <Card style={{ gap: 0, paddingBottom: 6 }}>
        <View style={[s.row, { marginBottom: 10 }]}>
          <Text
            style={{
              color: colors.text,
              fontSize: 12,
              fontWeight: "600",
              flex: 1,
            }}
          >
            Principais serviços por faturamento
          </Text>
          <Pressable
            accessibilityRole="button"
            onPress={() => setShowAll(!showAll)}
            style={{ flexDirection: "row", alignItems: "center", gap: 4 }}
          >
            <Text style={{ color: colors.accent, fontSize: 13 }}>
              {showAll ? "Ver menos" : "Ver todos"}
            </Text>
            <Icon name="chevron-forward" size={16} />
          </Pressable>
        </View>
        {ranking.slice(0, showAll ? ranking.length : 3).map((x, i) => (
          <View
            key={x.name}
            style={[
              s.row,
              {
                paddingVertical: 8,
                borderTopWidth: i ? 1 : 0,
                borderColor: colors.border,
              },
            ]}
          >
            <View
              style={{
                width: 29,
                height: 29,
                borderRadius: 16,
                backgroundColor: i ? "#49464D" : "#985A7C",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text style={{ color: colors.text, fontSize: 13 }}>{i + 1}</Text>
            </View>
            <Text style={{ color: colors.text, fontSize: 14, flex: 1 }}>
              {x.name}
            </Text>
            <Text style={{ color: colors.text, fontSize: 14 }}>
              {brl(x.total)}
            </Text>
          </View>
        ))}
        {!ranking.length && (
          <View style={{ paddingVertical: 14 }}>
            <Muted>Nenhum serviço concluído neste período.</Muted>
          </View>
        )}
      </Card>
      <View style={[s.row, { gap: 11 }]}>
        <View style={{ flex: 1 }}>
          <Button
            secondary
            icon="document-text-outline"
            title="Exportar PDF"
            disabled={busy || !data}
            onPress={() => download("pdf")}
          />
        </View>
        <View style={{ flex: 1 }}>
          <Button
            secondary
            icon="reader-outline"
            title="Exportar CSV"
            disabled={busy || !data}
            onPress={() => download("csv")}
          />
        </View>
      </View>
      <Modal
        visible={!!panel}
        transparent
        animationType="slide"
        onRequestClose={() => setPanel("")}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "#000000B8",
            justifyContent: "flex-end",
          }}
        >
          <View
            style={{
              backgroundColor: colors.bg,
              maxHeight: "85%",
              padding: 20,
              borderTopLeftRadius: 24,
              borderTopRightRadius: 24,
            }}
          >
            <View style={[s.row, { marginBottom: 16 }]}>
              <Title>
                {panel === "period"
                  ? "Selecionar período"
                  : "Selecionar profissional"}
              </Title>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Fechar filtros"
                onPress={() => setPanel("")}
              >
                <Icon name="close" size={24} />
              </Pressable>
            </View>
            <ScrollView
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ gap: 10, paddingBottom: 24 }}
            >
              {panel === "period" ? (
                <>
                  {choices.map((m) => (
                    <Pressable
                      accessibilityRole="button"
                      key={m}
                      onPress={() => {
                        setFrom(m + "-01");
                        const last = new Date(
                          Date.UTC(
                            Number(m.slice(0, 4)),
                            Number(m.slice(5, 7)),
                            0,
                            12,
                          ),
                        )
                          .toISOString()
                          .slice(0, 10);
                        setTo(m === today().slice(0, 7) ? today() : last);
                        setPanel("");
                      }}
                    >
                      <Card>
                        <Text style={{ color: colors.text }}>
                          {new Date(m + "-01T12:00:00Z").toLocaleDateString(
                            "pt-BR",
                            { month: "long", year: "numeric" },
                          )}
                        </Text>
                      </Card>
                    </Pressable>
                  ))}
                  <Card>
                    <Title>Período personalizado</Title>
                    <Field
                      label="De (AAAA-MM-DD)"
                      value={draftFrom}
                      onChangeText={setDraftFrom}
                    />
                    <Field
                      label="Até (AAAA-MM-DD)"
                      value={draftTo}
                      onChangeText={setDraftTo}
                    />
                    <Button
                      title="Aplicar período"
                      onPress={() => {
                        if (
                          !/^\d{4}-\d{2}-\d{2}$/.test(draftFrom) ||
                          !/^\d{4}-\d{2}-\d{2}$/.test(draftTo) ||
                          draftFrom > draftTo ||
                          Number.isNaN(Date.parse(draftFrom)) ||
                          Number.isNaN(Date.parse(draftTo))
                        ) {
                          setError("Informe um período válido.");
                          return;
                        }
                        setFrom(draftFrom);
                        setTo(draftTo);
                        setPanel("");
                      }}
                    />
                  </Card>
                </>
              ) : (
                ["Todos os profissionais", ...pros.map((p) => p.name)].map(
                  (name) => (
                    <Pressable
                      accessibilityRole="button"
                      key={name}
                      onPress={() => {
                        setProfessional(name);
                        setPanel("");
                      }}
                    >
                      <Card>
                        <View style={s.row}>
                          <Text style={{ color: colors.text }}>{name}</Text>
                          {professional === name && <Icon name="checkmark" />}
                        </View>
                      </Card>
                    </Pressable>
                  ),
                )
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </Screen>
  );
}
