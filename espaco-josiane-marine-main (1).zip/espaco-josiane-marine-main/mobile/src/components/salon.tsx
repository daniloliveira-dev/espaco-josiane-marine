import React from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  useWindowDimensions,
} from "react-native";
import Svg, { Path, Line, Rect, Text as SvgText } from "react-native-svg";
import { LinearGradient } from "expo-linear-gradient";
import { brl } from "../core";
import { Card, Icon, IconCircle, colors, s, type IconName } from "./ui";
export const dateOf = (start: string) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(start));
export const timeOf = (start: string) =>
  new Date(start).toLocaleTimeString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    hour: "2-digit",
    minute: "2-digit",
  });
export function shiftDay(date: string, n: number) {
  const d = new Date(date + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
export const longDay = (date: string) =>
  new Date(date + "T12:00:00Z").toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
export const percentage = (part: number, total: number) =>
  total > 0 ? Math.round((part / total) * 100) : 0;
export function Metric({
  label,
  value,
  hint,
  icon,
  tone = colors.accent,
  accent = false,
  onPress,
}: {
  label: string;
  value: number;
  hint: string;
  icon: IconName;
  tone?: string;
  accent?: boolean;
  onPress?: () => void;
}) {
  const { width } = useWindowDimensions();
  const compact = width < 390;
  const available =
    (Math.min(width, 560) - 36) / 2 - (compact ? 22 + 32 + 8 : 26 + 40 + 10);
  const moneySize = Math.min(20, available / (brl(value).length * 0.67));
  return (
    <Pressable
      accessibilityRole={onPress ? "button" : undefined}
      onPress={onPress}
      style={{ width: "48.8%", flexGrow: 1 }}
    >
      <Card style={[v.metric, compact && { padding: 11, gap: 8 }]}>
        <IconCircle name={icon} tone={tone} size={compact ? 32 : 40} />
        <View style={{ flex: 1, gap: 6 }}>
          <Text style={v.metricLabel}>{label}</Text>
          <Text
            numberOfLines={1}
            adjustsFontSizeToFit
            style={[
              v.metricNumber,
              { fontSize: moneySize },
              accent && { color: colors.accent },
            ]}
          >
            {brl(value)}
          </Text>
          <Text style={v.metricHint}>{hint}</Text>
        </View>
      </Card>
    </Pressable>
  );
}
export const statusColors: Record<string, string> = {
  confirmado: colors.accent,
  em_atendimento: colors.green,
  aguardando_confirmacao: colors.amber,
  concluido: colors.green,
  cancelado: "#88838A",
  nao_compareceu: "#CA6F7E",
};
export const statusLabels: Record<string, string> = {
  confirmado: "Confirmado",
  em_atendimento: "Em atendimento",
  aguardando_confirmacao: "Aguardando confirmação",
  concluido: "Concluído",
  cancelado: "Cancelado",
  nao_compareceu: "Não compareceu",
};
export function AppointmentRow({
  a,
  onPress,
  status = false,
  last = false,
}: {
  a: any;
  onPress: () => void;
  status?: boolean;
  last?: boolean;
}) {
  const tone = statusColors[a.status] || colors.accent;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${timeOf(a.start)}, ${a.client}, ${a.service_name}, ${statusLabels[a.status] || a.status}`}
      onPress={onPress}
      style={[
        v.appointment,
        !last && {
          borderBottomWidth: StyleSheet.hairlineWidth,
          borderBottomColor: colors.border,
        },
      ]}
    >
      <Text numberOfLines={1} style={v.time}>
        {timeOf(a.start)}
      </Text>
      <View
        style={{
          width: 4,
          height: status ? 46 : 40,
          borderRadius: 4,
          backgroundColor: tone,
        }}
      />
      <View style={{ flex: 1, gap: 6 }}>
        <Text numberOfLines={1} style={v.client}>
          {a.client || a.service_name}
        </Text>
        <Text numberOfLines={1} style={v.service}>
          {a.service_name}
        </Text>
      </View>
      {status ? (
        <View
          style={{
            maxWidth: 112,
            paddingVertical: 12,
            paddingHorizontal: 12,
            borderRadius: 20,
            backgroundColor: tone + "24",
          }}
        >
          <Text
            style={{
              color: a.status === "em_atendimento" ? "#B2E8CB" : colors.text,
              fontSize: 11,
              textAlign: "center",
            }}
          >
            {statusLabels[a.status] || a.status}
          </Text>
        </View>
      ) : (
        <Text numberOfLines={1} style={[s.muted, { maxWidth: 76 }]}>
          {a.professional}
        </Text>
      )}
      <Icon name="chevron-forward" size={18} color="#6E6A72" />
    </Pressable>
  );
}
export function Gauge({ value }: { value: number }) {
  const progress = Math.max(0, Math.min(100, value));
  const arc = "M 25 98 A 43 43 0 1 1 95 98";
  return (
    <View
      style={{
        width: 106,
        height: 102,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Svg width={106} height={102} viewBox="0 0 120 110">
        <Path
          d={arc}
          fill="none"
          stroke="#333137"
          strokeWidth={9}
          strokeLinecap="round"
        />
        <Path
          d={arc}
          fill="none"
          stroke={colors.accent}
          strokeWidth={9}
          strokeLinecap="round"
          strokeDasharray={`${(200 * progress) / 100} 200`}
        />
      </Svg>
      <Text
        style={{
          position: "absolute",
          fontSize: 20,
          fontWeight: "600",
          color: colors.text,
          top: 48,
        }}
      >
        {progress}%
      </Text>
    </View>
  );
}
export function CalendarStrip({
  date,
  onSelect,
  rows,
}: {
  date: string;
  onSelect: (d: string) => void;
  rows: any[];
}) {
  const d = new Date(date + "T12:00:00Z");
  const monday = shiftDay(date, -((d.getUTCDay() + 6) % 7));
  return (
    <View style={{ gap: 10 }}>
      <View style={s.row}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Semana anterior"
          hitSlop={10}
          onPress={() => onSelect(shiftDay(date, -7))}
        >
          <Icon name="chevron-back" size={18} color={colors.muted} />
        </Pressable>
        <Text style={{ color: colors.muted, fontSize: 12 }}>
          {d.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
        </Text>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Próxima semana"
          hitSlop={10}
          onPress={() => onSelect(shiftDay(date, 7))}
        >
          <Icon name="chevron-forward" size={18} color={colors.muted} />
        </Pressable>
      </View>
      <View style={{ flexDirection: "row", gap: 6 }}>
        {Array.from({ length: 7 }, (_, i) => {
          const day = shiftDay(monday, i);
          const count = rows.filter(
            (a) => dateOf(a.start) === day && a.status !== "cancelado",
          ).length;
          return (
            <Pressable
              key={day}
              accessibilityRole="button"
              accessibilityLabel={longDay(day)}
              accessibilityState={{ selected: day === date }}
              onPress={() => onSelect(day)}
              style={{ flex: 1 }}
            >
              <LinearGradient
                colors={
                  day === date ? ["#82435F", "#2A1B25"] : ["#171618", "#101011"]
                }
                style={{
                  borderRadius: 16,
                  alignItems: "center",
                  paddingVertical: 13,
                  gap: 7,
                }}
              >
                <Text
                  style={{
                    color: day === date ? "#EBCAD9" : colors.text,
                    fontSize: 12,
                  }}
                >
                  {["seg", "ter", "qua", "qui", "sex", "sáb", "dom"][i]}
                </Text>
                <Text
                  style={{
                    color: colors.text,
                    fontSize: 23,
                    fontWeight: "600",
                  }}
                >
                  {Number(day.slice(-2))}
                </Text>
                <Text style={{ color: colors.muted, fontSize: 11, height: 12 }}>
                  {"●".repeat(Math.min(3, count))}
                </Text>
              </LinearGradient>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
export function RevenueChart({
  entries,
  from,
  to,
  mode,
}: {
  entries: any[];
  from: string;
  to: string;
  mode: string;
}) {
  const days = Math.max(
    1,
    Math.min(
      366,
      Math.round(
        (new Date(to).getTime() - new Date(from).getTime()) / 86400000,
      ) + 1,
    ),
  );
  const groupSize =
    mode === "Semana"
      ? 7
      : mode === "Mês"
        ? 31
        : Math.max(1, Math.ceil(days / 31));
  const counts = Array.from({ length: Math.ceil(days / groupSize) }, () => 0);
  entries
    .filter((a) => a.status === "concluido")
    .forEach((a) => {
      const n = Math.round(
        (new Date(dateOf(a.start)).getTime() - new Date(from).getTime()) /
          86400000,
      );
      if (n >= 0 && n < days) counts[Math.floor(n / groupSize)] += a.price;
    });
  const max = Math.max(10000, ...counts);
  const ceiling = Math.ceil(max / 3 / 10000) * 10000;
  const top = ceiling * 3;
  const w = 360,
    h = 140,
    left = 34,
    chartW = w - left - 4,
    barW = chartW / counts.length;
  return (
    <Svg
      width="100%"
      height={90}
      preserveAspectRatio="none"
      viewBox={`0 0 ${w} ${h}`}
      accessibilityLabel={`Faturamento ${mode.toLowerCase()} no período, total ${brl(counts.reduce((a, b) => a + b, 0))}`}
    >
      <>
        {[0, 1, 2, 3].map((i) => (
          <React.Fragment key={i}>
            <Line
              x1={left}
              y1={108 - i * 30}
              x2={w}
              y2={108 - i * 30}
              stroke="#343137"
              strokeDasharray="4 3"
            />
            <SvgText x={0} y={112 - i * 30} fill={colors.muted} fontSize={10}>
              {i === 0
                ? "0"
                : ((ceiling * i) / 100000).toLocaleString("pt-BR") + " mil"}
            </SvgText>
          </React.Fragment>
        ))}
        {counts.map((value, i) => {
          const height = (value / top) * 90;
          return (
            <React.Fragment key={i}>
              <Rect
                x={left + i * barW + barW * 0.18}
                y={108 - height}
                width={Math.max(2, barW * 0.62)}
                height={height}
                rx={2}
                fill={colors.accent}
              />
              {(i === 0 ||
                i === counts.length - 1 ||
                i % Math.max(1, Math.floor(counts.length / 6)) === 0) && (
                <SvgText
                  x={left + i * barW + barW / 2}
                  y={126}
                  fill={colors.muted}
                  fontSize={10}
                  textAnchor="middle"
                >
                  {mode === "Dia"
                    ? Number(shiftDay(from, i * groupSize).slice(-2))
                    : i + 1}
                </SvgText>
              )}
            </React.Fragment>
          );
        })}
      </>
    </Svg>
  );
}
const v = StyleSheet.create({
  metric: {
    flexDirection: "row",
    gap: 10,
    padding: 13,
    minHeight: 96,
    alignItems: "flex-start",
  },
  metricLabel: { color: colors.muted, fontSize: 12 },
  metricNumber: { color: colors.text, fontSize: 20, fontWeight: "600" },
  metricHint: { color: colors.muted, fontSize: 11, lineHeight: 16 },
  appointment: {
    flexDirection: "row",
    gap: 14,
    paddingHorizontal: 19,
    paddingVertical: 16,
    alignItems: "center",
    minHeight: 66,
  },
  time: {
    color: colors.text,
    fontSize: 14,
    fontWeight: "600",
    width: 48,
    flexShrink: 0,
  },
  client: { color: colors.text, fontSize: 16 },
  service: { color: colors.muted, fontSize: 14 },
});
