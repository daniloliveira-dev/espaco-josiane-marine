import React from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  type StyleProp,
  type ViewStyle,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { router, usePathname } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useAuth } from "../core";
export const colors = {
  bg: "#030303",
  card: "#161517",
  accent: "#AF6892",
  text: "#FAF9FA",
  muted: "#AAA7B0",
  border: "#29272C",
  green: "#79BC9C",
  amber: "#F4A52F",
};
export const displayFont = "SalonDisplay";
export type IconName = React.ComponentProps<typeof Ionicons>["name"];
export function Icon({
  name,
  size = 22,
  color = colors.accent,
}: {
  name: IconName;
  size?: number;
  color?: string;
}) {
  return <Ionicons name={name} size={size} color={color} />;
}
export function IconCircle({
  name,
  tone = colors.accent,
  size = 42,
}: {
  name: IconName;
  tone?: string;
  size?: number;
}) {
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: tone + "20",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
      }}
    >
      <Icon name={name} color={tone} size={size * 0.48} />
    </View>
  );
}
export function Button({
  title,
  onPress,
  secondary = false,
  disabled = false,
  icon,
}: {
  title: string;
  onPress: () => void;
  secondary?: boolean;
  disabled?: boolean;
  icon?: IconName;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        s.button,
        secondary && {
          backgroundColor: "transparent",
          borderWidth: 1,
          borderColor: colors.accent,
        },
        (pressed || disabled) && { opacity: 0.5 },
      ]}
    >
      {icon && (
        <Icon
          name={icon}
          color={secondary ? colors.accent : colors.text}
          size={20}
        />
      )}
      <Text
        style={{
          color: secondary ? colors.accent : colors.text,
          fontWeight: "600",
          fontSize: 16,
          textAlign: "center",
        }}
      >
        {title}
      </Text>
    </Pressable>
  );
}
export function Field({
  label,
  value,
  onChangeText,
  secure = false,
  placeholder = "",
  numeric = false,
}: {
  label: string;
  value: string;
  onChangeText: (v: string) => void;
  secure?: boolean;
  placeholder?: string;
  numeric?: boolean;
}) {
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={s.label}>{label}</Text>
      <TextInput
        accessibilityLabel={label}
        value={value}
        onChangeText={onChangeText}
        secureTextEntry={secure}
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        autoCapitalize="none"
        keyboardType={numeric ? "decimal-pad" : "default"}
        style={s.input}
      />
    </View>
  );
}
export function Card({
  children,
  style,
}: {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <LinearGradient
      colors={["#19181A", "#121113"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[s.card, style]}
    >
      {children}
    </LinearGradient>
  );
}
export const Title = ({ children }: { children: React.ReactNode }) => (
  <Text style={s.title}>{children}</Text>
);
export const Muted = ({ children }: { children: React.ReactNode }) => (
  <Text style={s.muted}>{children}</Text>
);
export function Notice({
  message,
  error = false,
}: {
  message: string;
  error?: boolean;
}) {
  return message ? (
    <View
      accessibilityRole="alert"
      style={[s.notice, error && { borderColor: "#b75d71" }]}
    >
      <Text style={{ color: error ? "#ffb1c0" : colors.text }}>{message}</Text>
    </View>
  ) : null;
}
export function Chips({
  items,
  value,
  onSelect,
}: {
  items: { id: string | number; label: string }[];
  value: string | number;
  onSelect: (id: any) => void;
}) {
  return (
    <View style={s.wrap}>
      {items.map((x) => (
        <Pressable
          accessibilityRole="button"
          accessibilityState={{ selected: value === x.id }}
          key={x.id}
          onPress={() => onSelect(x.id)}
          style={[s.chip, value === x.id && { backgroundColor: colors.accent }]}
        >
          <Text style={{ color: colors.text, fontSize: 14 }}>{x.label}</Text>
        </Pressable>
      ))}
    </View>
  );
}
export function Segment({
  items,
  value,
  onSelect,
  small = false,
}: {
  items: string[];
  value: string;
  onSelect: (v: string) => void;
  small?: boolean;
}) {
  return (
    <View style={[s.segment, small && { padding: 3 }]}>
      {items.map((x) => (
        <Pressable
          key={x}
          accessibilityRole="button"
          accessibilityState={{ selected: value === x }}
          onPress={() => onSelect(x)}
          style={[
            s.segmentItem,
            small && { paddingVertical: 5, paddingHorizontal: 4 },
            value === x && { backgroundColor: small ? "#93486F" : "#542D46" },
          ]}
        >
          <Text
            style={{
              color: value === x ? "#F5D7E7" : colors.text,
              fontSize: small ? 11 : 16,
            }}
          >
            {x}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}
export function SectionHeading({
  title,
  action,
  onPress,
}: {
  title: string;
  action?: string;
  onPress?: () => void;
}) {
  return (
    <View style={[s.row, { marginTop: 6 }]}>
      <Text style={s.sectionTitle}>{title}</Text>
      {action && (
        <Pressable
          accessibilityRole="button"
          onPress={onPress}
          style={{ flexDirection: "row", alignItems: "center", gap: 5 }}
        >
          <Text style={{ color: colors.accent, fontSize: 14 }}>{action}</Text>
          <Icon name="chevron-forward" size={18} />
        </Pressable>
      )}
    </View>
  );
}
export function Screen({
  title,
  subtitle,
  children,
  busy = false,
  admin = false,
  back,
  hideNav = false,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  busy?: boolean;
  admin?: boolean;
  back?: string;
  hideNav?: boolean;
}) {
  const { session } = useAuth(),
    path = usePathname();
  const tabs =
    session?.user.role === "admin"
      ? [
          ["/home", "Hoje", "home"],
          ["/appointments", "Agenda", "calendar-outline"],
          ["/clients", "Clientes", "people-outline"],
          ["/cash", "Caixa", "wallet-outline"],
          ["/reports", "Relatórios", "bar-chart"],
        ]
      : [
          ["/booking", "Agendar", "add-circle-outline"],
          ["/appointments", "Meus horários", "calendar-outline"],
          ["/profile", "Perfil", "person-outline"],
        ];
  if (admin && session?.user.role !== "admin")
    return (
      <SafeAreaView style={s.root}>
        <Notice error message="Acesso exclusivo do administrador" />
      </SafeAreaView>
    );
  return (
    <SafeAreaView style={s.root} edges={["top", "left", "right", "bottom"]}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            s.container,
            { paddingBottom: session && !hideNav ? 120 : 40 },
          ]}
          keyboardShouldPersistTaps="handled"
        >
          {back ? (
            <View style={s.backHeader}>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={back}
                onPress={() =>
                  router.canGoBack()
                    ? router.back()
                    : router.replace("/appointments")
                }
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  position: "absolute",
                  left: 0,
                  zIndex: 1,
                }}
              >
                <Icon name="chevron-back" size={26} />
                <Text style={{ color: colors.accent, fontSize: 17 }}>
                  {back}
                </Text>
              </Pressable>
              <Text
                style={{ color: colors.text, fontSize: 19, fontWeight: "600" }}
              >
                {title}
              </Text>
            </View>
          ) : (
            <View style={s.header}>
              <View style={{ flex: 1 }}>
                <Text style={s.overline}>ESPAÇO JOSIANE MARINE</Text>
                <Text style={s.hero} adjustsFontSizeToFit numberOfLines={1}>
                  {title}
                </Text>
                {subtitle && <Muted>{subtitle}</Muted>}
              </View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Meu perfil e configurações"
                onPress={() => router.push("/profile")}
                style={s.monogram}
              >
                <Text style={s.monogramJ}>J</Text>
                <Text style={s.monogramM}>M</Text>
              </Pressable>
            </View>
          )}
          {busy && (
            <ActivityIndicator
              color={colors.accent}
              style={{ marginVertical: 8 }}
            />
          )}
          <View style={{ gap: 12 }}>{children}</View>
        </ScrollView>
      </KeyboardAvoidingView>
      {session && !hideNav && (
        <View style={s.navPosition}>
          <LinearGradient
            colors={["#1C1D1D", "#0E0D0E"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0.8 }}
            style={s.nav}
          >
            {tabs.map(([url, label, icon]) => {
              const active =
                path === url ||
                (url === "/clients" &&
                  ["/manage", "/operations", "/audit"].includes(path));
              return (
                <Pressable
                  key={url}
                  accessibilityRole="tab"
                  accessibilityState={{ selected: active }}
                  accessibilityLabel={label}
                  onPress={() => router.replace(url as any)}
                  style={[s.navItem, active && { backgroundColor: "#292328" }]}
                >
                  <Icon
                    name={icon as IconName}
                    size={24}
                    color={active ? colors.accent : colors.muted}
                  />
                  <Text
                    style={{
                      fontSize: 11,
                      color: active ? colors.accent : colors.muted,
                      marginTop: 5,
                    }}
                  >
                    {label}
                  </Text>
                </Pressable>
              );
            })}
          </LinearGradient>
        </View>
      )}
    </SafeAreaView>
  );
}
export const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  container: {
    paddingHorizontal: 14,
    paddingTop: 14,
    width: "100%",
    maxWidth: 560,
    alignSelf: "center",
    flexGrow: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 19,
    paddingHorizontal: 9,
    gap: 8,
  },
  overline: {
    fontSize: 10,
    color: colors.muted,
    letterSpacing: 2.5,
    marginBottom: 5,
  },
  hero: {
    fontFamily: displayFont,
    fontSize: 38,
    lineHeight: 43,
    color: colors.text,
    marginBottom: 4,
  },
  monogram: { width: 42, height: 56, position: "relative", marginTop: 12 },
  monogramJ: {
    fontFamily: displayFont,
    fontSize: 54,
    color: colors.accent,
    position: "absolute",
    left: 0,
    top: -8,
  },
  monogramM: {
    fontFamily: displayFont,
    fontSize: 39,
    color: colors.accent,
    position: "absolute",
    left: 11,
    top: 6,
  },
  backHeader: {
    height: 44,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 18,
  },
  card: { borderRadius: 17, padding: 16, gap: 12, overflow: "hidden" },
  title: { fontSize: 17, color: colors.text, fontWeight: "600" },
  sectionTitle: { fontFamily: displayFont, fontSize: 25, color: colors.text },
  muted: { color: colors.muted, fontSize: 14, lineHeight: 20 },
  label: { color: colors.muted, fontSize: 12, marginBottom: 7 },
  input: {
    color: colors.text,
    backgroundColor: "#0D0D0F",
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 12,
    padding: 13,
    fontSize: 16,
    minHeight: 48,
  },
  button: {
    backgroundColor: colors.accent,
    padding: 15,
    minHeight: 52,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 8,
  },
  chip: {
    paddingVertical: 12,
    paddingHorizontal: 22,
    backgroundColor: "#141315",
    borderRadius: 30,
  },
  wrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  segment: {
    flexDirection: "row",
    backgroundColor: "#141315",
    padding: 6,
    borderRadius: 30,
  },
  segmentItem: {
    flex: 1,
    paddingVertical: 11,
    paddingHorizontal: 8,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  notice: {
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.accent,
    backgroundColor: "#241b24",
  },
  navPosition: {
    position: "absolute",
    bottom: 8,
    left: 23,
    right: 23,
    alignItems: "center",
  },
  nav: {
    flexDirection: "row",
    borderWidth: 1,
    borderColor: "#2B2B2D",
    padding: 7,
    borderRadius: 42,
    width: "100%",
    maxWidth: 510,
    justifyContent: "space-around",
  },
  navItem: {
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    minHeight: 61,
    borderRadius: 34,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 8,
  },
  number: { fontSize: 23, color: colors.text, fontWeight: "600" },
  badge: {
    fontSize: 11,
    color: colors.accent,
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  divider: { height: StyleSheet.hairlineWidth, backgroundColor: colors.border },
  caption: {
    fontSize: 10,
    color: colors.muted,
    letterSpacing: 1.3,
    textTransform: "uppercase",
  },
});
